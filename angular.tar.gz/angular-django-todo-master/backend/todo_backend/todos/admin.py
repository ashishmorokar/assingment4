from django.contrib import admin
from todos.models import ToDo

admin.site.register(ToDo)
